package com.example.belolipetsckiy.belolipetsckiy_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelolipetsckiyBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelolipetsckiyBootApplication.class, args);
	}

}
