package com.example.belolipetsckiy.belolipetsckiy_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelolipetsckiyBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
